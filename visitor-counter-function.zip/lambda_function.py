import json
import boto3
import logging
from decimal import Decimal

# Set up logging
logging.getLogger().setLevel(logging.INFO)

def lambda_handler(event, context):
    try:
        # Log the entire event
        logging.info(f"Received event: {json.dumps(event, indent=2)}")

        # Initialize DynamoDB
        dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        table = dynamodb.Table('visitor-counter')

        # Get HTTP method
        http_method = event.get("httpMethod", event.get("requestContext", {}).get("http", {}).get("method", ""))
        logging.info(f"Raw httpMethod: {http_method}")
        http_method = str(http_method).upper()
        logging.info(f"Uppercase httpMethod: {http_method}")

        # Get origin
        origin = event.get("headers", {}).get("origin", "")
        if not origin:
            origin = "null"
        allowed_origins = ["http://localhost:3000", "https://kyle-miller.net", "https://www.kyle-miller.net"]
        response_origin = origin if origin in allowed_origins else "https://kyle-miller.net"

        # CORS headers
        cors_headers = {
            "Access-Control-Allow-Origin": response_origin,
            "Access-Control-Allow-Methods": "GET,PUT,OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Custom-Header",
            "Content-Type": "text/plain"
        }

        # Handle OPTIONS request (CORS preflight)
        if http_method == "OPTIONS":
            logging.info("Handling OPTIONS request")
            return {
                "statusCode": 200,
                "headers": cors_headers,
                "body": ""
            }

        # Handle PUT request
        if http_method == "PUT":
            # Get current item
            try:
                response = table.get_item(Key={'id': '123'})
                logging.info(f"DynamoDB get_item response: {response}")
            except Exception as e:
                logging.error(f"GetItem error: {str(e)}")
                raise

            # Check if item exists
            item = response.get('Item')
            if not item:
                logging.warning("Item with id '123' not found, initializing")
                count = 1  # Initialize count
            else:
                count = int(item.get('count', 0)) + 1  # Convert Decimal to int and increment

            # Update item
            try:
                response = table.put_item(Item={'id': '123', 'count': count})
                logging.info(f"DynamoDB put_item response: {response}")
            except Exception as e:
                logging.error(f"PutItem error: {str(e)}")
                raise

            # Return response
            logging.info(f"Returning count: {count}")
            return {
                "statusCode": 200,
                "headers": cors_headers,
                "body": str(count)
            }

        # Handle unsupported methods
        logging.warning(f"Unsupported method: {http_method}")
        return {
            "statusCode": 405,
            "headers": cors_headers,
            "body": json.dumps({"error": "Method Not Allowed"})
        }

    except Exception as e:
        logging.error(f"Unexpected error: {str(e)}")
        return {
            "statusCode": 500,
            "headers": {
                "Access-Control-Allow-Origin": response_origin,
                "Content-Type": "application/json"
            },
            "body": json.dumps({"error": f"Internal Server Error: {str(e)}"})
        }