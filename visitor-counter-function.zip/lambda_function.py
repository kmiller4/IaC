import boto3


def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('visitor-counter')

    try:
        response = table.get_item(
        Key={
                'id': '123'
            }
        )
        item = response['Item']
        count = item['count']
        count = count + 1
        response = table.put_item(                
            Item={
                'id': '123',
                'count': count
            }
        )
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Methods': '*'
            },
            'body': count
        }
    except:
        response = 'Error'
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',                    
                'Access-Control-Allow-Methods': '*'
            },
            'body': 'Error'
        }